//add this file to gitignore

module.exports={
    google: {
        clientID:"329574950710-ga8meri4moal69hj1at0d585f9dpc58d.apps.googleusercontent.com",
        clientSecret:"e1qwsolQ5MXZx9QmQcfToNZ8"
    },
   
}