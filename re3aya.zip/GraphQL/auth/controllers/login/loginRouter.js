const router = require('express').Router();
const passport = require('passport');

//AUTH Login

router.get('/login',(req,res)=>{
    res.send("helloooooo");
})

router.get('/failure',(req,res)=>{
    res.send("failure");
})

router.get('/login/google',passport.authenticate('google',{
    scope: ['profile']
}))


router.get('/login/google/redirect', 
  passport.authenticate('google', { failureRedirect: '/failure' }),
  function(req, res) {
    res.send("success");
    
  });


module.exports = router;